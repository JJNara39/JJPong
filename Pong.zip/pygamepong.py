# Trying to put pong into pygame

import pygame
from random import randint
import winsound

pygame.init()
# These are setting up our screen, our window
BLACK = (0,0,0)
WHITE = (255,255,255)

class Paddle(pygame.sprite.Sprite): # Making a Paddle Class, coming off of the Sprite family of objects
    def __init__(self, color, width, height):
        super().__init__() #calls the parent class constructor
        self.image = pygame.Surface([width, height]) # create the paddle
        self.image.fill(BLACK) # paddle's color
        self.image.set_colorkey(BLACK) # makes it transparent
        pygame.draw.rect(self.image, color, [0, 0, width, height]) #drawing a paddle
        self.rect = self.image.get_rect() # getting an image of a rectangle to give some dimensions

    def moveUp(self, pixels):
        self.rect.y -= pixels
        if self.rect.y < 0: #make sure we do not leave the screen
            self.rect.y = 0
    def moveDown(self, pixels):
        self.rect.y += pixels
        if self.rect.y > 400: #make sure we do not leave the screen
            self.rect.y = 400

class Ball(pygame.sprite.Sprite):
    def __init__(self, color, width, height):
        super().__init__()
        self.image = pygame.Surface([width, height])
        self.image.fill(BLACK)
        self.image.set_colorkey(BLACK)
        pygame.draw.rect(self.image, color, [0, 0, width, height]) #drawing a ball
        self.velocity = [randint(4,8),randint(-8,8)] # creates the x,y velocity
        self.rect = self.image.get_rect()
    def update(self): #gotta update cuz its moving
        self.rect.x += self.velocity[0]
        self.rect.y += self.velocity[1]
    def bounce(self):
        self.velocity[0] = -self.velocity[0]
        self.velocity[1] = randint(-8,8)
    def reset(self):
        self.rect.x = 350
        self.rect.y = 250
        self.velocity[0] = randint(-8,8)
        self.velocity[1] = randint(-8,8)

size = (700, 500)
wn = pygame.display.set_mode(size)
pygame.display.set_caption('Pong')
# Objects
paddleA = Paddle(WHITE, 10, 100)
paddleA.rect.x = 20
paddleA.rect.y = 200

paddleB = Paddle(WHITE, 10, 100)
paddleB.rect.x = 670
paddleB.rect.y = 200

ball = Ball (WHITE, 10, 10)
ball.rect.x = 345
ball.rect.y = 195

all_sprites_list = pygame.sprite.Group() # groups all of our sprites together in one list

# adding paddles and ball to list
all_sprites_list.add(paddleA)
all_sprites_list.add(paddleB)
all_sprites_list.add(ball)

running = True #variable to keep it running
clock = pygame.time.Clock()

# Scores
scoreA = 0
scoreB = 0

while running: # game loop
    for event in pygame.event.get(): # we get a list of events from pygame
        if event.type == pygame.QUIT: # if we use the Quit event, it closes
            running = False
        elif event.type==pygame.KEYDOWN:
            if event.key==pygame.K_x: #Pressing the x Key will quit the game
                running = False 

    # Moving the Paddles
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]:
        paddleA.moveUp(10)
    if keys[pygame.K_s]:
        paddleA.moveDown(10)
    if keys[pygame.K_UP]:
        paddleB.moveUp(10)
    if keys[pygame.K_DOWN]:
        paddleB.moveDown(10)
    # Game logic
    all_sprites_list.update()

    # Checking if the ball hit a wall

    if ball.rect.x>=690:
        scoreA += 1
        ball.reset()
    if ball.rect.x<=0:
        scoreB += 1
        ball.reset()
    if ball.rect.y>490:
        ball.velocity[1] = -ball.velocity[1]
    if ball.rect.y<0:
        ball.velocity[1] = -ball.velocity[1]

    # Find Collisions
    if pygame.sprite.collide_mask(ball, paddleA) or pygame.sprite.collide_mask(ball, paddleB):
        ball.bounce()

    # Drawing Code
    wn.fill(BLACK) # clear screen

    all_sprites_list.draw(wn) # drawing all the sprites on the window

    font = pygame.font.Font(None, 74)
    text = font.render(str(scoreA), 1, WHITE)
    wn.blit(text, (250,10))
    text = font.render(str(scoreB), 1, WHITE)
    wn.blit(text, (420,10))

    pygame.display.flip() # update with whats drawn
    clock.tick(60) # limit to 60 frames per second
pygame.quit() # Once game loop is done we need to stop game

        

"""
paddle_a.speed(0)
paddle_a.shape("square")
paddle_a.color("white")
paddle_a.shapesize(stretch_wid=5, stretch_len=1)
paddle_a.penup() # turtle objects draw a line when they move so we turn that off
paddle_a.goto(-350,0)

# Paddle B
paddle_b = turtle.Turtle() 
paddle_b.speed(0)
paddle_b.shape("square")
paddle_b.color("white")
paddle_b.shapesize(stretch_wid=5, stretch_len=1)
paddle_b.penup()
paddle_b.goto(350,0)

# Ball
ball = turtle.Turtle() 
ball.speed(0)
ball.shape("square")
ball.color("white")
ball.penup()
ball.goto(0,0)
ball.dx = 0.1
ball.dy = 0.1

# Pen
pen = turtle.Turtle()
pen.speed(0)
pen.color("white")
pen.penup()
pen.hideturtle()
pen.goto(0, 260)
pen.write("Player A: 0 Player B: 0" , align="center", font=("Courier", 24, "normal"))

# Functions
def paddle_a_up():
    y = paddle_a.ycor()
    y += 30
    paddle_a.sety(y)
def paddle_a_down():
    y = paddle_a.ycor()
    y -= 30
    paddle_a.sety(y)
def paddle_b_up():
    y = paddle_b.ycor()
    y += 30
    paddle_b.sety(y)
def paddle_b_down():
    y = paddle_b.ycor()
    y -= 30
    paddle_b.sety(y)

# Keyboard Binding
wn.listen()
wn.onkeypress(paddle_a_up, "w")
wn.onkeypress(paddle_a_down, "s")
wn.onkeypress(paddle_b_up, "Up")
wn.onkeypress(paddle_b_down, "Down")

# Main game loop
while True:
    wn.update() # every time the loop runs, the string will update

    # Move the ball
    ball.setx(ball.xcor() + ball.dx)
    ball.sety(ball.ycor() + ball.dy)

    # Border checking
    if ball.ycor() > 290: # top border
        ball.sety(290)
        ball.dy *= -1
        winsound.PlaySound("bounce.wav", winsound.SND_ASYNC)

    if ball.ycor() < -290: # bottom border
        ball.sety(-290)
        ball.dy *= -1
        winsound.PlaySound("bounce.wav", winsound.SND_ASYNC)

    if ball.xcor() > 390: #right border
        ball.goto(0,0)
        ball.dx *= -1
        score_a += 1
        pen.clear()
        pen.write("Player A: {} Player B: {}".format(score_a, score_b), align="center", font=("Courier", 24, "normal"))

    
    if ball.xcor() < -390: #left border
        ball.goto(0,0)
        ball.dx *= -1
        score_b += 1
        pen.clear()
        pen.write("Player A: {} Player B: {}".format(score_a, score_b), align="center", font=("Courier", 24, "normal"))


    # Paddle and ball collision
    if (ball.xcor() > 340 and ball.xcor() < 350) and (ball.ycor() < paddle_b.ycor() + 40 and ball.ycor() > paddle_b.ycor() - 40):
        ball.setx(340)
        ball.dx *= -1 # right bounce
        winsound.PlaySound("bounce.wav", winsound.SND_ASYNC)

    if (ball.xcor() < -340 and ball.xcor() > -350) and (ball.ycor() < paddle_a.ycor() + 40 and ball.ycor() > paddle_a.ycor() - 40):
        ball.setx(-340)
        ball.dx *= -1 # left bounce
         """